// ─────────────────────────────────────────────────────────────────────────────
// W5-A LEAD VALIDATION — lib/validation.ts
//
// The shape of a lead, stated once, for the only path by which a bereaved
// brother gets booked to speak. Both sites being replaced accepted anything the
// browser handed them and told the user it had been delivered:
//
//   DEFECT 1 (_legacy/components/TuvalMemorialLanding.tsx:30-45) — no schema, no
//   request, an alert() claiming receipt. 100% silent lead loss.
//   DEFECT 2 (ravid_website1/src/components/FormSection.tsx:19-37) — posts to a
//   third party and never reads the response, so a rejected lead renders success.
//
// INVARIANT     Every value that leaves this module has been LENGTH-BOUNDED and
//               CONTROL-CHARACTER-SCREENED. There is exactly one way to obtain a
//               `Lead` — `leadSchema.safeParse` returning `success: true` — and
//               `Lead` is INFERRED from that schema (`z.infer`), never written by
//               hand, so the type and the runtime check cannot disagree. The
//               locale union is imported from `@/config/site`; this file does not
//               spell `'he' | 'en'` and cannot drift from the app's locale set.
//               Unknown keys are STRIPPED by zod's default object behaviour, so
//               the parsed output contains exactly the six declared fields and
//               nothing a hostile client attached can travel further.
//
// IMPOSSIBLE    Mail-header injection can no longer be CONSTRUCTED from a lead.
//               `name`, `phone`, `email` and `organization` are the values that
//               reach header positions (Subject, Reply-To) in W5's mailer, and
//               every one of them rejects the full C0 range plus DEL — CR (000D)
//               and LF (000A) among them. So `"Ravid\r\nBcc: victim@example.org"`
//               is not a lead that gets sanitised downstream; it is not a `Lead`
//               at all, and no `safeParse` success can carry it. Equally out of
//               reach: an unbounded `message` (a 10 MB body is a rejection, not a
//               mail), a second hand-written `LeadInput` type drifting from the
//               schema, and a locale string the app has no messages for.
//
// CLASS         Closed by derivation for the SHAPE of a lead across the whole
//               app: every field's cap lives in `LEAD_FIELD_MAX` and every
//               single-line field is built by the same `singleLine()` factory, so
//               a seventh field added here is bounded and screened by
//               construction rather than by the author remembering to. NOT a
//               closure over CONTENT: see the limit.
//
// HONEST LIMIT  This validates SHAPE, never TRUTH. A well-formed lead can be
//               entirely fictional: `phone` is bounded and screened but its
//               FORMAT is deliberately unchecked (a memorial site rejecting a
//               real enquiry because a brother typed his number with a slash is
//               a worse failure than accepting a junk one), and `email` is only
//               checked when non-empty. It is not a spam filter and not a rate
//               limit — it cannot tell one hostile client from ten thousand.
//               The screen covers C0 + DEL; it does NOT reject U+2028/U+2029 or
//               bidi controls, which are display hazards, not SMTP header
//               terminators, and it does not attempt HTML/Unicode normalisation —
//               the mailer sends `text/plain`, so escaping is not this module's
//               job. `email` is trimmed here, but `name`/`phone`/`organization`
//               are trimmed only for the emptiness test, so interior double
//               spaces survive. And the caps are JUDGEMENTS, not measurements:
//               4000 characters of `message` is a long enquiry, not a proven
//               ceiling, and a legitimate lead longer than that is rejected with
//               a 4xx the client turns into its WhatsApp fallback (the client
//               sets no `maxLength`, so it cannot pre-empt this: see route.ts).
//
// NOTATION      THE FORBIDDEN SET IS SPELLED AS NUMBERS, AND MUST STAY THAT WAY.
//               Until 2026-09-13 this screen was two regex character classes
//               holding the control characters as RAW BYTES in the source. The
//               consequences were measured, not imagined: `file lib/validation.ts`
//               reported `data`, not text, and `grep` REFUSED TO READ THE FILE
//               (`grep -c leadSchema lib/validation.ts` exited 1 on a symbol that
//               was plainly there) — a live production module invisible to every
//               text sweep in the repo while those sweeps reported zero hits.
//               Worse, the failure mode was SILENT: one formatter run, one editor
//               save or one `sed` that dropped the unprintable bytes would have
//               left an EMPTY character class, which matches nothing, and this
//               mail-header guard would have vanished with no error, no failing
//               test and no gate.
//
//               So the set is now built at module load from NUMERIC CODE POINTS.
//               A number literal denotes no character, so no tool can —unescape—
//               it into one — the exact hazard that bit this repo four times via
//               backslash escapes (ledger D-82, D-94, D-131) — and there is no
//               character class left for an edit to empty. The C0 half is
//               GENERATED from its length rather than listed, so there is no
//               enumeration for a careless edit to silently shorten either.
//               NEVER reintroduce a raw control byte here, and never respell this
//               as an escape inside a string or regex literal. The proof that the
//               screen still FIRES is not this comment: it is
//               `lib/__tests__/validation.test.ts`, which drives every code point
//               0x00-0x7f through `leadSchema` itself and goes red the instant the
//               screen stops rejecting.
// ─────────────────────────────────────────────────────────────────────────────

import { z } from 'zod';

import { DEFAULT_LOCALE, LOCALES } from '@/config/site';

/**
 * Every cap in the module, in one object. An unbounded field is a
 * denial-of-service vector (parse cost, mail size) and a mail-injection surface,
 * so no field is exempt.
 */
export const LEAD_FIELD_MAX = {
  name: 120,
  phone: 40,
  /** RFC 5321 maximum reverse-path length. */
  email: 254,
  organization: 160,
  message: 4000,
} as const;

/**
 * THE forbidden set, stated ONCE, as numbers: the C0 controls U+0000-U+001F —
 * which contain CR U+000D and LF U+000A, the pair that terminates a mail header
 * — plus DEL U+007F. A value containing any of these may never reach a header.
 *
 * The C0 half is GENERATED from its length, not listed, so there is no
 * enumeration for an edit to silently shorten. See NOTATION in the file header
 * for why this is numbers and not a character class.
 */
const C0_CODE_POINT_COUNT = 0x20;
const DELETE_CODE_POINT = 0x7f;

const HEADER_UNSAFE_CODE_POINTS: ReadonlySet<number> = new Set([
  ...Array.from({ length: C0_CODE_POINT_COUNT }, (_unused, index) => index),
  DELETE_CODE_POINT,
]);

/**
 * TAB, LF and CR. `message` is a multi-line body value and never a header, so
 * these three are legitimate content there — and nothing else in the set is.
 */
const BODY_PERMITTED_CODE_POINTS: ReadonlySet<number> = new Set([0x09, 0x0a, 0x0d]);

/**
 * DERIVED, never restated: the same forbidden set minus the three above. One
 * fact, one place — widen the header set and the body set widens with it, so the
 * two screens cannot drift into disagreeing about what a control character is.
 */
const BODY_UNSAFE_CODE_POINTS: ReadonlySet<number> = new Set(
  Array.from(HEADER_UNSAFE_CODE_POINTS).filter(
    (codePoint) => BODY_PERMITTED_CODE_POINTS.has(codePoint) === false,
  ),
);

/**
 * True when any code point of `value` is in `forbidden`. Iterates CODE POINTS,
 * so an astral character is one item and never its two surrogate halves; proved
 * equivalent to the regex classes this replaced over all 1,114,112 code points
 * plus every lone surrogate (see the W14-FIX2 report).
 */
function containsForbidden(forbidden: ReadonlySet<number>, value: string): boolean {
  for (const character of value) {
    const codePoint = character.codePointAt(0);
    if (codePoint !== undefined && forbidden.has(codePoint)) {
      return true;
    }
  }
  return false;
}

/** The machine-readable rule name reported when a screen rejects. */
const CONTROL_RULE = 'control_character';

/**
 * A bounded, header-safe, single-line string. Every field that can reach a mail
 * header is built from this, so the screen is applied by construction.
 */
function singleLine(max: number) {
  return z
    .string()
    .max(max)
    .trim()
    .refine((value) => containsForbidden(HEADER_UNSAFE_CODE_POINTS, value) === false, {
      message: CONTROL_RULE,
    });
}

/**
 * The lead as the client posts it. Verified against
 * `components/sections/LeadForm.tsx` (its `JSON.stringify` body): six keys, all
 * strings, the four optional ones sent as `''` rather than omitted. Both are
 * accepted here — absent and empty mean the same thing for an optional field.
 */
export const leadSchema = z.object({
  /** Required. Reaches the mail Subject. */
  name: singleLine(LEAD_FIELD_MAX.name).min(1),

  /** Required. The only reliably reachable contact channel for an Israeli lead. */
  phone: singleLine(LEAD_FIELD_MAX.phone).min(1),

  /**
   * Optional. Reaches Reply-To, so it is screened AND must be a real address
   * when present — a malformed Reply-To is a bounced reply, i.e. a lost lead.
   */
  email: z
    .string()
    .max(LEAD_FIELD_MAX.email)
    .trim()
    .pipe(z.union([z.literal(''), z.email()]))
    .default(''),

  /** Optional. Reaches the mail Subject alongside `name`. */
  organization: singleLine(LEAD_FIELD_MAX.organization).default(''),

  /** Optional. Body only, so newlines are allowed and nothing else is. */
  message: z
    .string()
    .max(LEAD_FIELD_MAX.message)
    .refine((value) => containsForbidden(BODY_UNSAFE_CODE_POINTS, value) === false, {
      message: CONTROL_RULE,
    })
    .default(''),

  /**
   * The app's locale union, imported — never re-declared. Absent means the
   * site's default; a value outside the union is a rejection, not a fallback,
   * because a lead tagged `de` came from a client this app did not serve.
   */
  locale: z.enum(LOCALES).default(DEFAULT_LOCALE),
});

/**
 * THE lead type. Inferred, so a field added above is a compile error at every
 * consumer rather than a silently missing line in an email.
 */
export type Lead = z.infer<typeof leadSchema>;

/** One rejected field, in a form a client can branch on without reading prose. */
export type LeadIssue = {
  readonly field: string;
  readonly code: string;
  readonly rule: string;
};

/**
 * Turn a parse failure into a machine-readable list. `path` is joined so nested
 * fields stay addressable; `code` is zod's own issue code and `rule` carries the
 * refinement name for the custom screens (zod reports every refinement as
 * `custom`, which alone cannot tell a caller WHICH screen rejected).
 */
export function formatIssues<T>(error: z.ZodError<T>): readonly LeadIssue[] {
  return error.issues.map((issue) => ({
    field: issue.path.map(String).join('.'),
    code: issue.code,
    rule: issue.message,
  }));
}
